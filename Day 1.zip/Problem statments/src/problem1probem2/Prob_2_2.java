package problem1probem2;

public class Prob_2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
