package problem6;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
	public static void main(String[] args) {
//	     Scanner s=new Scanner(System.in);
//		    int f=  s.nextInt();
//		    System.out.println("Enter the name");
	      ArrayList<String> names = new ArrayList<String>();
	      names.add("Naresh");
	      names.add("rohit");
	      names.add("ishan");
	      names.add("polly");
	    
	      System.out.println(names);
	 
	     System.out.println(names.contains("Naresh"));
	   } 
}




