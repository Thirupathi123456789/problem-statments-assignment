package bookstore.servlet;

public class SetPasswordServlet {

}
